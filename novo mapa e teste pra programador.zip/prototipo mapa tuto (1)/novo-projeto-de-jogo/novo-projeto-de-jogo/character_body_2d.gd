extends CharacterBody2D


var SPEED = 300.0
const JUMP_VELOCITY = -500.0
var dash = false
var time = 10
var can_dash = true
var jumps = 2
var collision_point = 0

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
		if Input.is_key_pressed(KEY_DOWN):
			velocity += get_gravity() 
			
	# Input direction
	var direction := Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	# Handle jump.
	if Input.is_action_just_pressed("ui_accept") and jumps > 0:
		velocity.y = JUMP_VELOCITY
		jumps -= 1
		can_dash = true
	if is_on_floor():
		jumps = 2
	
	# Wall Jump
	if is_on_wall_only():
		velocity *= 0.8
		if Input.is_action_just_pressed("ui_accept"):
			velocity.y = JUMP_VELOCITY * 2
			jumps = 2

	# Dash
	if Input.is_key_pressed(KEY_SHIFT):
		if can_dash == true:
			if is_on_floor():
				SPEED += 150
				dash = true
				can_dash = false
			else:
				SPEED += 1500
				dash = true
				can_dash = false
	if dash == true:
		time -= 1
	if time == 0:
		dash = false
		time = 10
		SPEED = 300
	if is_on_floor():
		can_dash = true
	
	move_and_slide()
