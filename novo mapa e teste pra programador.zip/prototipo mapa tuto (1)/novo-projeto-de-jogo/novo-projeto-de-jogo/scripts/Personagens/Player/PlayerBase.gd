extends PersonagemBase

func _ready() -> void:
	Escala_original = Sprite.scale
	StaminaBar.position.x = 50.0
	# Criar velocidade de movimento
	GerenciadorDeVelocidade.CriarVelocidade("Movimento",Vector2(300.0,0))
	GerenciadorDeVelocidade.Velocidades["Movimento"].Smoothness = 7.50
	# Criar velocidade de pulo
	GerenciadorDeVelocidade.CriarVelocidade("Pulo",Vector2(0,-750.0))
	GerenciadorDeVelocidade.Velocidades["Pulo"].Smoothness = 5.0
	# Criar velocidade de escalada
	GerenciadorDeVelocidade.CriarVelocidade("Escalada",Vector2(0,150.0))
	GerenciadorDeVelocidade.Velocidades["Escalada"].Smoothness = 10.0
	# Criar velocidade do WallJump
	GerenciadorDeVelocidade.CriarVelocidade("WallJump",Vector2(300.0,0))
	GerenciadorDeVelocidade.Velocidades["WallJump"].Smoothness = 7.50
	GerenciadorDeVelocidade.Velocidades.WallJump.Decai = true
	
	GerenciadorDeVelocidade.CriarVelocidade("Rolagem",Vector2(750.0,0))
	GerenciadorDeVelocidade.Velocidades["Rolagem"].Smoothness = 7.50
	
	conectar_sinal_one_shot(TocarNoChao,ao_tocar_no_chao)
	conectar_sinal_one_shot(SairDoChao,ao_sair_do_chao)
	
	conectar_sinal_one_shot(SubirNaParede,ao_subir_na_parede)
	
	conectar_sinal_one_shot(Rastejar,ao_rastejar)

@onready var Sprite = $Sprite2D
@onready var StaminaBar = $Stamina
@onready var IndicadorEstado = $IndicadorDeEstado             
@onready var Timers = {
	"Rolamento": {
		"Duracao": $"Timers/Rolamento/DuraçãoRolagem",
		"Cooldown": $Timers/Rolamento/Cooldown,
	},
	"Pulo": {
		"Buffer": $"Timers/Pulo/Buffer",
	},
	"WallJump": {
		"Duracao": $"Timers/WallJump/DuraçãoWallJump"
	}
}
var Estados = { # Estado: [booleana,prioridade]
	"Parado": [true,0],
	"Airborne": [false,3],
	"Andando": [false,1],
	"Pulando": [false,4],
	"Rastejando": [false,2],
	"NaParede": [false,4],
	"Escalando": [false,5],
	"Rolando": [false,4]
}

var EmPulo = false
var Permissoes = {
	"Movimento": true,
	"Rolar": true,
	"Pular": true,
}
var Direcao = 1
var Escala_original

var Multiplicadores = {
	"Movimento": 1.0,
	"Pulo": 1.0,
}

# Sinais
# Sair e tocar no chão
signal TocarNoChao
signal SairDoChao
# Rastejar
signal Rastejar
signal Levantar
# Subir na parede
signal SubirNaParede
signal DescerDaParede

# Buffer de pulo
var buffer_valido = false

func conectar_sinal_one_shot(sinal: Signal, funcao_alvo: Callable):
	if not sinal.is_connected(funcao_alvo):
		sinal.connect(funcao_alvo,CONNECT_ONE_SHOT)

func EscolherEstado(dicionario: Dictionary):
	var ListaDePrioridade = []
	for estado in dicionario:
		var array = dicionario[estado]
		if array[0] == true:
			ListaDePrioridade.push_back(array[1])
		else:
			ListaDePrioridade.push_back(-1)
	var MaiorPrioridade = ListaDePrioridade.find(ListaDePrioridade.max())
	return dicionario.keys()[MaiorPrioridade]

# Para fazer squash e stretch
func SquashStretch(multiplicadores_da_escala: Vector2, duracao: float):
	var tween = create_tween()
	var escala_base = Escala_original
	var escala_alvo = Sprite.scale * multiplicadores_da_escala
	# Esticar
	tween.tween_property(Sprite,"scale",escala_alvo,duracao * 0.5).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	# Voltar ao normal
	tween.tween_property(Sprite,"scale",escala_base,duracao * 0.5).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
# Executar o pulo
func Jump(booleana: bool):
	Estados.Pulando[0] = booleana
	if booleana == true:
		GerenciadorDeVelocidade.Velocidades.Pulo.Play(Multiplicadores.Pulo)
		print(Multiplicadores.Pulo)
		SquashStretch(Vector2(0.9,1.1),0.25)
	else:
		GerenciadorDeVelocidade.Velocidades.Pulo.Stop(true)

func Walk(booleana: bool, mult: float = 1):
	Estados.Andando[0] = booleana
	if booleana == true:
		GerenciadorDeVelocidade.Velocidades.Movimento.Play(mult)
	else:
		GerenciadorDeVelocidade.Velocidades.Movimento.Stop()

func Crawl(booleana: bool):
	if booleana == true:
		Rastejar.emit()
	else:
		Levantar.emit()

func OnWall(booleana: bool):
	if booleana == true:
		Estados.NaParede[0] = true
		SubirNaParede.emit()
	else:
		Estados.NaParede[0] = false
		DescerDaParede.emit()

func Climb(booleana: bool, delta: float, mult: float = 1):
	if booleana == true:
		Estados.Escalando[0] = true
		GerenciadorDeVelocidade.Velocidades.Escalada.Play(mult)
		StaminaBar.value = clamp(StaminaBar.value - 15 * delta,0,100)
	else:
		Estados.Escalando[0] = false
		GerenciadorDeVelocidade.Velocidades.Escalada.Stop()
	
func WallJump(booleana: bool):
	if booleana == true:
		var WallNormal = get_wall_normal()
		GerenciadorDeVelocidade.Velocidades.WallJump.Play(WallNormal.x)
		Jump(true)
		Permissoes.Movimento = false
		Timers.WallJump.Duracao.start()
	else:
		GerenciadorDeVelocidade.Velocidades.WallJump.Stop(false)
	
func Roll(booleana: bool, mult: float = 1):
	if booleana == true:
		Estados.Rolando[0] = true
		GerenciadorDeVelocidade.Velocidades.Rolagem.Play(mult)
		Permissoes.Movimento = false
		Timers.Rolamento.Duracao.start()
	else:
		Estados.Rolando[0] = false
		Permissoes.Movimento = true
		GerenciadorDeVelocidade.Velocidades.Rolagem.Stop(false)

func _physics_process(delta: float) -> void:
	GerenciadorDeVelocidade.Atualizar(delta)
	var ValorInput = Vector2((Input.get_axis("SetaEsquerda","SetaDireita")),(Input.get_axis("ui_up","ui_down")))
	
	var EstadoAtual = EscolherEstado(Estados)
	IndicadorEstado.text = EstadoAtual
	# Sinal para pousada
	if is_on_floor():
		TocarNoChao.emit()
	# Sinal para sair do chao
	if not is_on_floor():
		SairDoChao.emit()
	# Flipar o sprite
	if ValorInput.x != 0:
		Direcao = ValorInput.x
		if Direcao > 0:
			StaminaBar.position.x = -50.0
			Sprite.flip_h = true
		else:
			StaminaBar.position.x = 50.0
			Sprite.flip_h = false
	
	# Gravidade
	AtualizarGravidade((Estados.Airborne[0] == true) and (Estados.NaParede[0] == false or StaminaBar.value == 0.0),delta)
	
	# Andar
	if ValorInput.x != 0 and Permissoes.Movimento == true:
		Walk(true,Direcao * Multiplicadores.Movimento)
	else:
		Walk(false)
	
	# Pulo
	if Input.is_action_just_pressed("Tecla Z"):
		if is_on_floor():
			Jump(true)
		elif not is_on_floor():
			buffer_valido = true
			Timers.Pulo.Buffer.start()
	if is_on_ceiling():
		Jump(false)
		# Rastejar
	if Input.is_action_pressed("Tecla X") and Estados.Airborne[0] == false:
		Crawl(true)
	else:
		Crawl(false)
	
	if Input.is_action_just_pressed("Tecla C") and Estados.Airborne[0] == false and Estados.NaParede[0] == false and not Estados.Rolando[0]:
		Roll(true,Direcao)
	
	# Subir na parede
	if is_on_wall_only() or (is_on_wall() and Input.is_action_just_pressed("ui_up")):
		OnWall(true)
	else: OnWall(false)
	
	if not Estados.NaParede[0] and not Estados.Airborne[0]:
		StaminaBar.value = clamp(StaminaBar.value + 15 * delta,0,100)
	
	if Estados.NaParede[0] and ValorInput.y != 0:
		Climb(true, delta, ValorInput.y)
	else:
		Climb(false, delta)
	
	if Estados.NaParede[0] == true and Input.is_action_just_pressed("Tecla Z"):
		WallJump(true)
	
	velocity = GerenciadorDeVelocidade.RetornarSoma()
	move_and_slide()


func ao_tocar_no_chao():
	conectar_sinal_one_shot(SairDoChao,ao_sair_do_chao)
	Jump(false)
	WallJump(false)
	SquashStretch(Vector2(1.05,0.95),0.25)
	Estados.Airborne[0] = false
	if buffer_valido:
		Jump(true)
	


func ao_sair_do_chao():
	conectar_sinal_one_shot(TocarNoChao,ao_tocar_no_chao)
	Estados.Airborne[0] = true


func ao_rastejar():
	Estados.Rastejando[0] = true
	conectar_sinal_one_shot(Levantar,ao_levantar)
	Multiplicadores.Movimento = clamp(Multiplicadores.Movimento - 0.5,0,INF)


func ao_levantar():
	Estados.Rastejando[0] = false
	conectar_sinal_one_shot(Rastejar,ao_rastejar)
	Multiplicadores.Movimento = clamp(Multiplicadores.Movimento + 0.5,0,INF)

func ao_subir_na_parede():
	conectar_sinal_one_shot(DescerDaParede,ao_descer_da_parede)
	Multiplicadores.Pulo = clamp(Multiplicadores.Pulo - 0.35,0,INF)
	Jump(false)
	WallJump(false)
	if buffer_valido:
		WallJump(true)

func ao_descer_da_parede():
	conectar_sinal_one_shot(SubirNaParede,ao_subir_na_parede)
	Multiplicadores.Pulo = clamp(Multiplicadores.Pulo + 0.35,0,INF)

func _on_buffer_timeout() -> void:
	buffer_valido = false


func _on_duração_wall_jump_timeout() -> void:
	WallJump(false)
	Permissoes.Movimento = true


func _on_duração_rolagem_timeout() -> void:
	Roll(false)
