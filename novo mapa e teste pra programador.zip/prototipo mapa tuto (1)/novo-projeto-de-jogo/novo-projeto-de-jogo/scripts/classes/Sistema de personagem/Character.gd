extends CharacterBody2D
class_name PersonagemBase

var GerenciadorDeVelocidade = GerenciadorVelocidades.new()
# Condições para o funcionamento da gravidade
func _init() -> void:
	GerenciadorDeVelocidade.CriarVelocidade("Gravidade",get_gravity(), false)

func AtualizarGravidade(CondicoesDaGravidade: bool,delta: float):
	if CondicoesDaGravidade:
		GerenciadorDeVelocidade.Velocidades["Gravidade"].VelAtual += get_gravity() * delta * GerenciadorDeVelocidade.Velocidades["Gravidade"].Multiplicador
	else:
		GerenciadorDeVelocidade.Velocidades["Gravidade"].VelAtual = Vector2(0,0)
