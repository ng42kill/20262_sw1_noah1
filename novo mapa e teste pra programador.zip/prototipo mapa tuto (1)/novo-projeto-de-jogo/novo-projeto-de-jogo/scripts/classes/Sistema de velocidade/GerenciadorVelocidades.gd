extends RefCounted
class_name GerenciadorVelocidades
var Velocidades = {}

func CriarVelocidade(nome: String, base: Vector2, auto: bool = true):
	var NovaVelocidade = Velocidade.new()
	NovaVelocidade.VelBase = base
	NovaVelocidade.Auto = auto
	Velocidades[nome] = NovaVelocidade
	

func RetornarSoma():
	var Soma = Vector2(0,0)
	for vel in Velocidades.values():
		Soma = Soma + vel.VelAtual
	return Soma

func Atualizar(delta: float):
	for velocidade in Velocidades.values():
		if velocidade.Auto == true:
			var Smoothness = velocidade.Smoothness
			var speed = min(delta * Smoothness,1.0)
			var DistanciaX = abs(velocidade.VelAlvo.x - velocidade.VelAtual.x)
			var DistanciaY = abs(velocidade.VelAlvo.y - velocidade.VelAtual.y)
			if DistanciaX > 0.1:
				velocidade.VelAtual.x = lerp(velocidade.VelAtual.x,velocidade.VelAlvo.x,speed)
			else:
				velocidade.VelAtual.x = velocidade.VelAlvo.x
				if velocidade.Decai == true:
					velocidade.VelAlvo.x = 0
		
			if DistanciaY > 0.1:
				velocidade.VelAtual.y = lerp(velocidade.VelAtual.y,velocidade.VelAlvo.y,speed)
			else:
				velocidade.VelAtual.y = velocidade.VelAlvo.y
				if velocidade.Decai == true:
					velocidade.VelAlvo.y = 0
