extends RefCounted
class_name Velocidade


var VelBase = Vector2(0,0) # Velocidade normal
var VelAlvo = Vector2(0,0) # Velocidade que deve ser alcançada gradualmente
var VelAtual = Vector2(0,0) # Velocidade que muda em tempo real para alcançar a alvo
var Multiplicador = 1.0 # Multiplicador que irá afetar a velocidade alvo sempre que der play
var Auto = true # Define se a velocidade vai ser atualizada automaticamente pelo Atualizar() do gerenciador. Se desligado, pode ser manipulada apenas manualmente
var Decai = false # Define se a velocidade alvo chega a 0 depois que a atual alcança ela
var Smoothness = 5.0 # O quão gradual a velocidade muda

func Play(MultiplicadorDoPlay = 1.0):
	VelAlvo = VelBase * Multiplicador * MultiplicadorDoPlay

func Stop(atual_para_zero: bool = false):
	VelAlvo = Vector2(0,0)
	
	if atual_para_zero:
		VelAtual = Vector2(0,0)
	
