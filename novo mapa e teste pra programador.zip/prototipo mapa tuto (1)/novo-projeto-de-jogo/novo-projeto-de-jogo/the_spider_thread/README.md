README


Disciplina: Desenvolvimento Mobile / IA
Professora: Joelma Sartori
Integrantes do grupo:
Aluno 1: Noah Godoy / 25039
Aluno 2: Abraão Batista da Silva / 25095
Aluno 3: Yuri Henzo Saito / 25060
Aluno 4: Kasane Teto / 25401
Aluno 5: Theo Almeida / 25236

1. Pesquisa Teórica

1.1 Machine Learning
O que é:
A prática de "ensinar" uma máquina a aprender, fazendo com que ela adapte por conta própria usando seu "conhecimento" de como diferir ações positivas, negativas, e qual delas usar em uma situação.

Para que serve e onde é utilizado:
Machine Learning é frequentemente utilizado no mercado de trabalho para cumprir tarefas que consequentemente seriam muito longas, repetitivas ou difíceis para humanos normais, automatizando processos e economizando dinheiro e mentes.

1.2 Google Teachable Machine
O que é a ferramenta:
Uma ferramenta web que permite integrar machine learning em seus projetos, sem ter que escrever o código para ela.

Finalidade e funcionamento:
Criar máquinas inteligentes capaz de reconhecer imagens caso seu projeto necessite, usando apenas a ferramenta em vez de ter que codificar esta função.
Ela funciona pois já tem o código de aprendizado, e o usuário apenas precisa utiliza-lo e/ou integra-lo pronto em seu projeto.

Exemplos práticos de uso:
1. Criando um APP de segurança que utiliza biometria facial, e necessita de um programa que reconhece a face da pessoa.
2. Criando um organizador que identifica a marca de vários produtos e os separa devidamente.

1.3 Integração com Flutter
Exportação do Modelo:
Após criar um modelo de machine learning usando o flutter, poderá o exportar para uso externo quando ter a integração de uso, ou seja, quando estiver pronto para ser usado para aprender em outros projetos de pessoas que importarem este código 
quando necessitarem de uso de máquinas inteligentes em vosso projeto.

Como carregar e rodar no Flutter:
Se você já tem o projeto baixado do flutter, apenas precisa rodar ele no terminal usando "flutter run" para executar o projeto e verificar de que ele esteja funcionando plenamente.

2. Proposta para a Feira Tecnológica / de Ciências

Nome do Projeto:
The Spider's Thread
Proposta de Valor:
O conhecimento avançado da "mente de programador", e atendimento aos vícios de jogos de Parkour.

Tecnologias Utilizadas
- [Godot Game Engine](https://godotengine.org/)
- [Git & Github](https://github.com/)

Histórico de Commits e Atualizações:
- merge. push, commit e etc são tudo uma dor de cabeça pra manusear. Era melhor ter feito em um branch só. Com sorte o rework conserte essa caquinha.
- adição de obstáculos, confecção de mapas e integração de um "void"
- Término da Pesquisa Teórica
- rework do sistema de movimento
