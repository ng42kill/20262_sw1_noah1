extends Area2D
class_name deathfloor
# Called when the node enters the scene tree for the first time. 
func _ready() -> void:
	body_entered.connect(enter_body) 

func enter_body(body: Node2D) -> void:
	if body is ghost:
		get_tree().reload_current_scene()

# can you say that again I'm being distract actually let me mute them hold on
func _process(delta: float) -> void:
	pass
