extends CharacterBody2D
class_name ghost

var walking = false
# Timers -------------------------------------------------------------------------------------------
@onready var timers = {
	"dash": $timers/dash/dash_timer,
	"dash_cooldown": $timers/dash/dash_cooldown,
	"ghost_effect": $timers/dash/ghost_effect
}
# Objetos ------------------------------------------------------------------------------------------
@onready var objects = {
	"char_sprite": $Sprite2D,
	"char_collision": $CollisionShape2D,
	"char_camera": $Camera2D
}

# Velocidades --------------------------------------------------------------------------------------
# X ------------------------------------------------------------------------------------------------
# Base ---------------------------------------------------------------------------------------------
var base_x_velocity = {
	"walk": 400.0,
	"dash": 1000.0,
}
# Atual --------------------------------------------------------------------------------------------
var current_x_velocity = {
	"walk": 0.0,
	"dash": 0.0,
	"knockback": 0.0,
	}
# --------------------------------------------------------------------------------------------------
# Y ------------------------------------------------------------------------------------------------
var base_y_velocity = {
	"jump": -500.0,
	"dash": -1000.0,
}
# --------------------------------------------------------------------------------------------------
# Propriedades -------------------------------------------------------------------------------------
var properties = {
	"direction": 1
}

# Estados ------------------------------------------------------------------------------------------
var states = {
	"walking": false,
	"dashing": false,
	"on_wall": false,
	"diving": false
}

# Permissions --------------------------------------------------------------------------------------
var permissions = {
	"can_walk": true,
	"can_jump": true,
	"can_dash": true,
	"can_gravity": true,
	"can_dive": true
}

# Multiplicadores ----------------------------------------------------------------------------------
var multipliers = {
	"walk": 1,
	"jump": 1,
	"dash": 1,
	"gravity": 1
}
# Funções ------------------------------------------------------------------------------------------

# Efeito do dash -----------------------------------------------------------------------------------
func dash_ghost_effect():
	var sprite_clone = Sprite2D.new()
	sprite_clone.texture = objects["char_sprite"].texture
	sprite_clone.global_position = objects["char_sprite"].global_position
	get_tree().current_scene.add_child(sprite_clone)
	
	sprite_clone.modulate = Color(0.75,0.75,1)
	
	var tween = create_tween()
	tween.tween_property(sprite_clone,"modulate:a",0,0.3)
	tween.tween_callback(sprite_clone.queue_free)

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor() and not states["on_wall"] and permissions["can_gravity"]:
		velocity += (get_gravity() * multipliers["gravity"]) * delta

	# Input checking -------------------------------------------------------------------------------
	var x_input := Input.get_axis("ui_left", "ui_right")
	var y_input := Input.get_axis("ui_up", "ui_down")

# Jumping ------------------------------------------------------------------------------------------
	if Input.is_action_just_pressed("key_z") and is_on_floor() and not states["on_wall"] and not is_on_wall():
		velocity.y += base_y_velocity["jump"]
	
# Handle velocity ----------------------------------------------------------------------------------
	var velocity_x = 0.0
	for index in current_x_velocity:
		if index in multipliers:
			velocity_x += (current_x_velocity[index] * multipliers[index])
		else:
			velocity_x += current_x_velocity[index]
	velocity.x = velocity_x
	
# Handle knockback ---------------------------------------------------------------------------------
	if abs(current_x_velocity["knockback"]) > 0.1:
		current_x_velocity["knockback"] = lerp(current_x_velocity["knockback"],0.0,5.0 * delta)
	if abs(current_x_velocity["knockback"]) <= 0.1 and abs(current_x_velocity["knockback"]) != 0:
		current_x_velocity["knockback"] = 0.0
	
	
# Walking ------------------------------------------------------------------------------------------

	if Input.is_action_just_pressed("ui_left"):
		properties["direction"] = -1.0
	if Input.is_action_just_pressed("ui_right"):
		properties["direction"] = 1.0
	
	
	if x_input and permissions["can_walk"] == true:
		states["walking"] = true
		current_x_velocity["walk"] = base_x_velocity["walk"] * properties["direction"]
	
	if (not x_input or permissions["can_walk"] == false) and states["walking"] == true:
		walking = false
		current_x_velocity["walk"] = lerp(current_x_velocity["walk"],0.0,8.0 * delta)
# Dashing ------------------------------------------------------------------------------------------

# Dash on key C
	if Input.is_action_just_pressed("key_c") and permissions["can_dash"] == true and not states["diving"]:
		var dashed = false # Variable to grant that the player won't lose dash if a bug happens
		if not states["on_wall"]:
			if Input.is_action_pressed("ui_up") and not x_input:
				permissions["can_gravity"] = false
				velocity.y = 0
				velocity.y += base_y_velocity["dash"] * multipliers["dash"]
				dashed = true
			if not Input.is_action_pressed("ui_up"):
				permissions["can_gravity"] = false
				velocity.y = 0
				current_x_velocity["dash"] += base_x_velocity["dash"] * properties["direction"]
				dashed = true
			if Input.is_action_pressed("ui_up") and x_input:
				current_x_velocity["dash"] += (base_x_velocity["dash"] * properties["direction"]) / 1.5
				permissions["can_gravity"] = false
				velocity.y = 0
				velocity.y += (base_y_velocity["dash"] * multipliers["dash"]) / 1.5
				dashed = true
		if states["on_wall"]:
			permissions["can_gravity"] = false
			velocity.y = 0
			current_x_velocity["dash"] += base_x_velocity["dash"] * -properties["direction"]
			dashed = true
			
		if dashed == true:
			states["dashing"] = true
			permissions["can_walk"] = false
			permissions["can_dash"] = false
			timers["dash"].start()
	
# Dash velocity lerp

	if states["dashing"] == false and abs(current_x_velocity["dash"]) > 0.1:
		current_x_velocity["dash"] = lerp(current_x_velocity["dash"],0.0,5.0 * delta)
	if abs(current_x_velocity["dash"]) != 0 and abs(current_x_velocity["dash"]) <= 0.1:
		current_x_velocity["dash"] = 0

# Dash ghost effect
	if states["dashing"] == true:
		if timers["ghost_effect"].is_stopped():
			dash_ghost_effect()
			timers["ghost_effect"].start()
	
# Dive ---------------------------------------------------------------------------------------------
	print(multipliers["gravity"])
	if Input.is_action_just_pressed("key_x") and not states["diving"] and permissions["can_dive"] and not is_on_floor():
		states["diving"] = true
		states["dashing"] = true
		permissions["can_walk"] = false
		permissions["can_dash"] = false
		multipliers["gravity"] += 3
	
	if is_on_floor() and states["diving"]:
		states["diving"] = false
		states["dashing"] = false
		permissions["can_walk"] = true
		permissions["can_dash"] = true
		multipliers["gravity"] -= 3
	
# Wall jump ----------------------------------------------------------------------------------------
	
	# Changing the gravity and applying the on_wall state
	if is_on_wall_only() and not states["on_wall"]:
		states["on_wall"] = true
		velocity.y = 100
		var wall_normal = get_wall_normal()
	
	if not is_on_wall_only():
		states["on_wall"] = false
	
	# Jumping off the wall
	if Input.is_action_just_pressed("key_z") and permissions["can_jump"] and states["on_wall"]:
		var wall_normal = get_wall_normal()
		if wall_normal.x > 0:
			current_x_velocity["knockback"] += 1000
			velocity.y += base_y_velocity["jump"] * 1.5
		else:
			current_x_velocity["knockback"] -= 1000
			velocity.y += base_y_velocity["jump"] * 1.5

	move_and_slide()

# Stop dash
func _on_dash_timer_timeout() -> void:
	states["dashing"] = false
	permissions["can_walk"] = true
	permissions["can_gravity"] = true
	timers["dash_cooldown"].start()

# Dash cooldown
func _on_dash_cooldown_timeout() -> void:
	permissions["can_dash"] = true
